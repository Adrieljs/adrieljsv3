const ms = require('ms');

exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "Giveaways Manager")){
        return message.channel.send('You need \`ADMINISTRATOR\` permission or \`Giveaways Manager\` role');
    }
    // If no message ID or giveaway name is specified
    if(!args[0]){
        return message.channel.send('No valid message ID was provided. Example: \`741980723824689212\`');
    }

    // try to found the giveaway with prize then with ID
    let giveaway = 
    // Search with giveaway prize
    client.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
    // Search with giveaway ID
    client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

    // If no giveaway was found
    if(!giveaway){
        return message.channel.send('Invalid giveaway message ID!`'+ args.join(' ') + '`.');
    }

    // Edit the giveaway
    client.giveawaysManager.edit(giveaway.messageID, {
        setEndTimestamp: Date.now()
    })
    // Success message
    .then(() => {
        // Success message
        message.channel.send('Giveaway will end in less than '+(client.giveawaysManager.options.updateCountdownEvery/1000)+' seconds...');
    })
    .catch((e) => {
        if(e.startsWith(`Giveaway with message ID ${giveaway.messageID} has already ended.`)){
            message.channel.send('This giveaway has already ended!');
        } else {
            console.error(e);
            message.channel.send('An error occured whilst trying to execute this command and it has been logged.');
        }
    });

};
module.exports.config = {
    name: "gend",
    description: "Picks a giveaway winner instantly, ending the giveaway.",
    usage: "gend <Giveaway ID>",
    accessableby: "Admins",
    aliases: ["g-end", "ge"],
    example: ["gend 747336462223147168"],
    input: "gend 747336462223147168\n*THIS ID WON'T WORK!\n \n \n",
    output: "Giveaway will end in less than 5 seconds...\n \n \n \n",
    warning: "Picks winners below winnercount if the winner goal is not reached."
}