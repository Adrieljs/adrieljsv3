exports.run = async (client, message, args) => {
    const { channel } = message.member.voice;
    if(!message.member.hasPermission('MANAGE_CHANNELS') && !message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "DJ")){
      return message.channel.send('You need \`MANAGE_CHANNELS\` permission or \`DJ\` role!');
    };
    if (!channel)
      return message.channel.send(
        "Please connect to a voice channel."
      );
    const serverQueue = message.client.queue.get(message.guild.id);
    if (!serverQueue)
      return message.channel.send(
        "There is nothing playing."
      );
    serverQueue.songs = [];
    serverQueue.connection.dispatcher.end();
    return message.channel.send(`Music session stopped by **${message.author.tag}**.`);
};
module.exports.config = {
  name: "disconnect",
  description: "Disconnects from vc and clears the server's music queue.",
  usage: "disconnect",
  accessableby: "DJ",
  aliases: ["leave", "dc", "d"],
  example: ["disconnect"],
  input: "disconnect\n \n \n \n",
  output: "Music session stopped by x#yyyy.\n📤 No songs available, successfully disconnected.\n \n \n",
  warning: "safe"
}
