exports.run = async (client, message, args) => {
    client.guilds.cache.forEach(g => {
        console.log(g.name);
    })
}
module.exports.config = {
    name: "",
    description: "Not for public use",
    usage: "",
    accessableby: "Developer",
    aliases: [],
    example: [],
    input: "\n \n \n \n ",
    output: "\n \n \n \n ",
    warning: "Keep out from public."
}