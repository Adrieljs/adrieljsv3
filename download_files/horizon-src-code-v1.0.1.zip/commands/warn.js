const db = require('quick.db');
const Discord = require('discord.js');

exports.run = async (client, message, args) => {
    if(!message.member.hasPermission('MANAGE_MESSAGES') || !message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "Moderator"))
    return message.channel.send("You need \`MANAGE_MESSAGES\` permission or \`Moderator\` role!");

    let mentioned = message.mentions.users.first();
    if(args[0] === !mentioned) return message.channel.send(
        "Provide a valid mentioned user to be warned!"
        );
    if(mentioned === undefined) return message.channel.send(
    "Provide a valid mentioned user to be warned!"
    );
    if(mentioned === message.author) return message.channel.send(
        "You can't warn yourself!"
    );
    if(mentioned.bot) return message.channel.send(
        "You can't warn a bot!"
    );
    if(args[1] === "-s") {
        if(args[2]) {
            let reason = args.slice(2).join(" ");
            db.add(`warns_in_${message.guild.id}_for_${mentioned}`, 1);
            db.push(`warns_reason_in_${message.guild.id}_for_${mentioned}`, `${reason}`);
            let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
            let embed = new Discord.MessageEmbed()
                .setDescription(`You were warned in [${message.guild.name}](https://id?=${message.guild.id})\n**Reason:** ${reason}\n**By:** [${message.author.tag}](https://id?=${message.author.id})
**Your warns in the server:** ${warnsCount}`)
                .setColor("#6762A6");
            mentioned.send(embed);
            message.delete();
        };
        if(!args[2]) {
            let reason = "No reason was provided";
            db.add(`warns_in_${message.guild.id}_for_${mentioned}`, 1);
            db.push(`warns_reason_in_${message.guild.id}_for_${mentioned}`, `${reason}`);
            let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
            let embed = new Discord.MessageEmbed()
                .setDescription(`You were warned in [${message.guild.name}](https://id?=${message.guild.id})\n**Reason:** ${reason}\n**By:** [${message.author.tag}](https://id?=${message.author.id})
**Your warns in the server:** ${warnsCount}`)
                .setColor("#6762A6");
            mentioned.send(embed);
            message.delete();
        };
    };

    if(args[1] != "-s") {
        if(args[1]) {
            let reason = args.slice(1).join(" ");
            db.add(`warns_in_${message.guild.id}_for_${mentioned}`, 1);
            db.push(`warns_reason_in_${message.guild.id}_for_${mentioned}`, `${reason}`);
            let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
            let embed = new Discord.MessageEmbed()
                .setDescription(`You were warned in [${message.guild.name}](https://id?=${message.guild.id})\n**Reason:** ${reason}\n**By:** [${message.author.tag}](https://id?=${message.author.id})
**Your warns in the server:** ${warnsCount}`)
                .setColor("#6762A6");
            let embedch = new Discord.MessageEmbed()
                .setDescription(`${mentioned} has been warned.\n**Reason:** ${reason}\n**By:** [${message.author.tag}](https://id?=${message.author.id})\n**Their warns in the server:** ${warnsCount}`)
                .setColor("#6762A6");
                mentioned.send(embed);
            message.channel.send(embedch);
        };
        if(!args[1]) {
            let reason = "No reason was provided";
            db.add(`warns_in_${message.guild.id}_for_${mentioned}`, 1);
            db.push(`warns_reason_in_${message.guild.id}_for_${mentioned}`, `${reason}`);
            let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
            let embed = new Discord.MessageEmbed()
                .setDescription(`You were warned in [${message.guild.name}](https://id?=${message.guild.id})\n**Reason:** ${reason}\n**By:** [${message.author.tag}](https://id?=${message.author.id})
**Your warns in the server:** ${warnsCount}`)
                .setColor("#6762A6");
            let embedch = new Discord.MessageEmbed()
                .setDescription(`${mentioned} has been warned.\n**Reason:** ${reason}\n**By:** [${message.author.tag}](https://id?=${message.author.id})\n**Their warns in the server:** ${warnsCount}`)
                .setColor("#6762A6");
                mentioned.send(embed);
            message.channel.send(embedch);
        };
    };

    
};
module.exports.config = {
    name: "warn",
    description: "Warns someone on command. (Type -s for a silent warn on the server, but still privately message them when warned)",
    usage: "warn <mentioned> [-s] [Reason]",
    accessableby: "Moderators",
    aliases: ["w"],
    example: ["\nwarn @Discord_Guy62","\nwarn @Discord_Guy62 no","\nwarn @Discord_Guy62 -s", "\nwarn @Discord_Guy62 -s no"],
    input: "warn @Discord_Guy62 no\n \n \n \n",
    output: "*Embed\n@Discord_Guy62 has been warned.\nReason: no\nBy: You#0431\n...",
    warning: "safe"
}