const fetch = require('node-fetch');
const pagination = require('discord.js-pagination');
const Discord = require('discord.js');
const db = require('quick.db');
const { default_prefix } = require('../config.json');

exports.run = async (client, message, args) => {
    if (!args[0]) {
        fetch(`https://corona.lmao.ninja/v3/covid-19/all?allowNull=true`)
        .then(response => response.json())
        .then(data => {
            let confirmed = data.cases.toLocaleString();
            let todayCases = data.todayCases.toLocaleString();
            let updated = data.updated.toLocaleString();
            let todayDeaths = data.todayDeaths.toLocaleString();
            let todayRecovered = data.todayRecovered.toLocaleString();
            let active = data.active.toLocaleString();
            let critical = data.critical.toLocaleString();
            let casesPerOneMillion = data.casesPerOneMillion.toLocaleString();
            let deathsPerOneMillion = data.deathsPerOneMillion.toLocaleString();
            let tests = data.tests.toLocaleString();
            let testsPerOneMillion = data.testsPerOneMillion.toLocaleString();
            let population = data.population.toLocaleString();
            let activePerOneMillion = data.activePerOneMillion.toLocaleString();
            let recoveredPerOneMillion = data.recoveredPerOneMillion.toLocaleString();
            let criticalPerOneMillion = data.criticalPerOneMillion.toLocaleString();
            let affectedCountries = data.affectedCountries.toLocaleString();
            let banner = `https://media.discordapp.net/attachments/657874805638299648/744388678323011665/the-world-national-flags_4.png?width=1006&height=671`
            let recovered = data.recovered.toLocaleString();
            let deaths = data.deaths.toLocaleString();

        const embed = new Discord.MessageEmbed()
        .setThumbnail(banner)
        .setTitle('COVID-19 Worldwide Statistics')
        .addFields(
            { name: "\u200B\nGENERAL", value: "\u200B", inline: false },
            { name: "World Population", value: `\`${population}\``, inline: true },
            { name: "Affected Countries", value: `\`${affectedCountries}\``, inline: true },
            { name: "Tests", value: `\`${tests}\``, inline: true},
            { name: "Confirmed", value: `\`${confirmed}\``, inline: true },
            { name: "Active", value: `\`${active}\``, inline: true },
            { name: "Critical", value: `\`${critical}\``, inline: true },
            { name: "Deaths", value: `\`${deaths}\``, inline: true },
            { name: "Recovered", value: `\`${recovered}\`\n`, inline: true },
        )
        .addFields(
            { name: "\u200B\nDETAILED", value: "\u200B", inline: false },
            { name: "Today cases", value: `\`+${todayCases}\``, inline: true },
            { name: "Today deaths", value: `\`+${todayDeaths}\``, inline: true },
            { name: "Today recovered", value: `\`+${todayRecovered}\``, inline: true },
            { name: "Tests per million", value: `\`${testsPerOneMillion}\``, inline: true },
            { name: "Cases per million", value: `\`${casesPerOneMillion}\``, inline: true },
            { name: "Active per million", value: `\`${activePerOneMillion}\``, inline: true },
            { name: "Critical per million", value: `\`${criticalPerOneMillion}\``, inline: true },
            { name: "Deaths per million", value: `\`${deathsPerOneMillion}\``, inline: true },
            { name: "Recovered per million", value: `\`${recoveredPerOneMillion}\``, inline: true }
        )
        .setFooter(`Updated ${updated} times, data from Worldometer`)
        .setColor("#6762A6");
        message.channel.send(embed);
        })
    }

    if(args[0]) {
        let countries = args.join(" ");
        let prefix = db.get(`prefix_${message.guild.id}`);
        if (prefix === null) prefix = default_prefix; 
        fetch(`https://corona.lmao.ninja/v3/covid-19/countries/${countries}?allowNull=true`)
        .then(response => response.json())
        .then(data => {
            let confirmed = data.cases.toLocaleString();
            let todayCases = data.todayCases;
            let updated = data.updated.toLocaleString();
            let todayDeaths = data.todayDeaths;
            let todayRecovered = data.todayRecovered;
            let active = data.active.toLocaleString();
            let critical = data.critical;
            let casesPerOneMillion = data.casesPerOneMillion.toLocaleString();
            let deathsPerOneMillion = data.deathsPerOneMillion.toLocaleString();
            let tests = data.tests.toLocaleString();
            let id = data.countryInfo._id.toLocaleString();
            let iso2 = data.countryInfo.iso2.toLocaleString();
            let iso3 = data.countryInfo.iso3.toLocaleString();
            let testsPerOneMillion = data.testsPerOneMillion.toLocaleString();
            let population = data.population.toLocaleString();
            let activePerOneMillion = data.activePerOneMillion.toLocaleString();
            let recoveredPerOneMillion = data.recoveredPerOneMillion.toLocaleString();
            let criticalPerOneMillion = data.criticalPerOneMillion;
            let country = data.country.toLocaleString();
            let flag = data.countryInfo.flag.toLocaleString();
            let recovered = data.recovered.toLocaleString();
            let deaths = data.deaths.toLocaleString();
            let continent = data.continent.toLocaleString();
            let oneCasePerPeople = data.oneCasePerPeople.toLocaleString();
            let oneDeathPerPeople = data.oneDeathPerPeople.toLocaleString();
            let oneTestPerPeople = data.oneTestPerPeople.toLocaleString();
            const embed = new Discord.MessageEmbed()
            .setThumbnail(flag)
            .setTitle(`${country}`)
            .addFields(
                { name: "\u200B\nGENERAL", value: "\u200B", inline: false },
                { name: "Population", value: `\`${population}\``, inline: true },
                { name: "Tests", value: `\`${tests}\``, inline: true},
                { name: "Confirmed", value: `\`${confirmed}\``, inline: true },
                { name: "Active", value: `\`${active}\``, inline: true },
                { name: "Critical", value: `\`${critical}\``, inline: true },
                { name: "Deaths", value: `\`${deaths}\``, inline: true },
                { name: "Recovered", value: `\`${recovered}\`\n`, inline: true },
            )
            .addFields(
                { name: "\u200B\nDETAILED", value: "\u200B", inline: false },
                { name: "Today cases", value: `\`+${todayCases}\``, inline: true },
                { name: "Today deaths", value: `\`+${todayDeaths}\``, inline: true },
                { name: "Today recovered", value: `\`+${todayRecovered}\``, inline: true },
                { name: "Tests per million", value: `\`${testsPerOneMillion}\``, inline: true },
                { name: "Cases per million", value: `\`${casesPerOneMillion}\``, inline: true },
                { name: "Active per million", value: `\`${activePerOneMillion}\``, inline: true },
                { name: "Critical per million", value: `\`${criticalPerOneMillion}\``, inline: true },
                { name: "Deaths per million", value: `\`${deathsPerOneMillion}\``, inline: true },
                { name: "Recovered per million", value: `\`${recoveredPerOneMillion}\``, inline: true },
                { name: "a test per x people", value: `\`${oneTestPerPeople}\``, inline: true },
                { name: "a case per x people", value: `\`${oneCasePerPeople}\``, inline: true },
                { name: "a death per x people", value: `\`${oneDeathPerPeople}\``, inline: true },
            )
            .setColor("#6762A6");
            const embed1 = new Discord.MessageEmbed()
            .setTitle(`${country}`)
            .setThumbnail(flag)
            .addFields(
                { name: "\u200B\nINFO", value: "\u200B", inline: false },
                { name: "Country Name", value: `\`${country}\``, inline: true },
                { name: "Continent", value: `\`${continent}\``, inline: true },
                { name: "Country ID", value: `\`${id}\``, inline: true },
                { name: "Aliases", value: `\`${iso2}\`, \`${iso3}\``}
            )
            .setColor("#6762A6");

            const pages = [
                embed,
                embed1
            ]
            const emojiList = ["⏪", "⏩"];
            const timeout = '120000';
    
            pagination(message, pages, emojiList, timeout);
            }
        )
    }
}
module.exports.config = {
    name: "corona",
    description: "Shows COVID-19 statistics t",
    usage: "corona [Country name/id/iso2/iso3]",
    accessableby: "Members",
    aliases: ["covid", "cov", "cor", "covid19"],
    example: ["corona", "corona indonesia", "corona 360", "corona ID", "corona IDN"],
    input: "corona indonesia\n \n \n \n",
    output: "*Embed\nConfirmed: 153535\nActive: 39355\nRecovered: 107500\n...",
    warning: "Doesn't output errors when country is invalid, many datas aren't reported yet, and it is replaced with null."
}