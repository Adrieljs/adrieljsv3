const pagination = require('discord.js-pagination');
const Discord = require('discord.js');
const db = require('quick.db');
const { default_prefix } = require('../config.json'); 

exports.run = async (client, message, args) => {
let prefix = db.get(`prefix_${message.guild.id}`);
if (prefix === null) prefix = default_prefix;
if(!args[0]) {
        const Music = new Discord.MessageEmbed()
            .setTitle("🎧 Music")
            .addFields(
                { name: "play", value: "=> Plays a song with provided name/link."},
                { name: "queue", value: "=> Gives a list of songs in the queue."},
                { name: "volume", value: "=> Turns a volume up to whichever suitable for you."},
                { name: "stop", value: "=> Pauses the current song."},
                { name: "resume", value: "=> Resumes the current paused song."},
                { name: "skip", value: "=> Skips the current song."},
                { name: "disconnect", value: "=> Stops the bot from providing music, disconnects from the voice channel."},
            )
            .setColor("#6762A6");
        const first = new Discord.MessageEmbed()
            .setTitle("📑 Home Page")
            .addFields(
                { name: 'Server prefix', value: `\`${prefix}\``},
                { name: "Help", value: `To get a more detailed information about a command, please use \n\`${prefix}help COMMAND_NAME\``},
                { name: "Syntax", value: `<...> is a required field, [...] is an optional field.`},
                { name: "What's new?", value: `Added a cross-server chat, \`${prefix}global\` for more information`},
                { name: "\u200B", value: `Please switch to next page using ⏪ or ⏩ for a list of commmands.\n\n[Bot Invite](https://discord.com/api/oauth2/authorize?client_id=731510386184159282&permissions=8&scope=bot) \`|\` [Support Server](https://discord.com/invite/P8w2m6d) \`|\` Made by 1mmunity#5719 `}
            )
            .setColor("#6762A6");
        const Giveaways = new Discord.MessageEmbed()
            .setTitle(`🎉 Giveaway`)
            .addFields(
                { name: `gstart`, value: "=> Starts a giveaway."},
                { name: `greroll`, value: "=> Rerolls a winner"},
                { name: `gend`, value: "=> Ends a giveaway."}
            )
            .setColor("#6762A6");
        const Fun = new Discord.MessageEmbed()
            .setTitle('🪀 Fun')
            .addFields(
                { name: `meme`, value: "=> Fetches a random meme from meme subreddits."},
                { name: `minesweeper`, value: "=> Generates a minesweeper game."},
                { name: `ascii`, value: "=> Turns provided text into an ascii text."}
            )
            .setColor("#6762A6");
        const Utils = new Discord.MessageEmbed()
                .setTitle('🤖 Bot')
                .addFields(
                    { name: `prefix`, value: "=> Sets a prefix for this server."},
                    { name: `h!preset`, value: "=> Sets the prefix in the server to default in case you forget it."},
                    { name: `help`, value: "=> Shows lists of commands."}
                )
                .setColor("#6762A6");
        const Infos = new Discord.MessageEmbed()
                .setTitle('ℹ️ Information')
                .addFields(
                    { name: "corona", value: "=> Shows COVID-19 Statistics."},
                    { name: "translate", value: "=> Translates text from provided language."}
                )
                .setColor("#6762A6");
        const Moderation = new Discord.MessageEmbed()
                .setTitle('👮 Moderation')
                .addFields(
                    { name: "warn", value: "=> Warns mentioned user with or with no reason." },
                    { name: "checkwarn", value: "=> Checks mentioned user's warns with reasons." },
                    { name: "deletewarn", value: "=> Deletes mentioned user's warns." }
                )
                .setColor("#6762A6");
        const Features = new Discord.MessageEmbed()
                .setTitle("✨ Features")
                .addFields(
                    { name: "global", value: "=> Gives a guide on how to use and set up global chat + info."}
                )
                .setColor("#6762A6");
        const InDev = new Discord.MessageEmbed()
                .setTitle("💡 Indev")
                .addFields(
                    { name: "ban", value: "=> In development."},
                    { name: "kick", value: "=> In development."},
                    { name: "mute", value: "=> In development."}
                )
                .setColor("#6762A6");
        const pages = [
            first,
            Giveaways,
            Utils,
            Moderation,
            Music,
            Infos,
            Fun,
            InDev
        ]
        const emojiList = ["⏪", "⏩"];
        const timeout = '120000';

        pagination(message, pages, emojiList, timeout)
}

if (args[0]) {
    const argos = args
const commandos = argos.shift().toLowerCase();
const command = client.commands.get(commandos) || client.commands.get(client.aliases.get(commandos));
    const embedp1 = new Discord.MessageEmbed()
        .setTitle(`Command: ${command.config.name}`)
        .setDescription(`
            **Description:** ${command.config.description || "-"}\n**Usage:** ${prefix}${command.config.usage || "-"}\n**Aliases:** ${command.config.aliases.map(x => `${prefix}${x}`).join(", ") || "-"}\n**Accessibility:** ${command.config.accessableby || "Members"}\n**Example:** ${command.config.example.map(y => `${prefix}${y}`).join("\n") || "-"}
            
        `)
        .setColor("#6762A6");
    const embedp2 = new Discord.MessageEmbed()
        .setTitle(`Command: ${command.config.name}`)
        .setDescription(`
            **Expected Input Example**
            \`\`\`console\n${command.config.input}\`\`\`\n**Expected Output**\n\`\`\`console\n${command.config.output}\`\`\`\n**Warnings:** ${command.config.warning || "safe"}
        `)
        .setColor("#6762A6");
        const pages2p = [
            embedp1,
            embedp2
        ]
        const emojiList2p = ["⏪", "⏩"];
        const timeout2p = "120000";
    pagination(message, pages2p, emojiList2p, timeout2p);
}
}
    module.exports.config = {
        name: "help",
        description: "Gets a list of commands, if name is provided, it will give informations about it.",
        usage: "help [command name]",
        accessableby: "Members",
        aliases: ["h"],
        example: ["help", "help play"],
        input: "help\n \n \n \n",
        output: "*Embed\nMain Page\nServer prefix\nh!\n...",
        warning: "safe"
    }