const db = require('quick.db');
const Discord = require('discord.js');
exports.run = async (client, message, args) => {
    if(!message.member.hasPermission('MANAGE_MESSAGES') || !message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "Moderator")) {
    return message.channel.send("You need \`MANAGE_MESSAGES\` permission or \`Moderator\` role!");
};
    let mentioned = message.mentions.users.first();
    if(args[0] === !mentioned) return message.channel.send(
        "Provide a valid mentioned user to be warnchecked!"
        );
    if(mentioned === undefined) return message.channel.send(
    "Provide a valid mentioned user to be warnchecked!"
    );
    if(args[1] != "-s") {
        let reason = db.get(`warns_reason_in_${message.guild.id}_for_${mentioned}`);
        let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
        let index = 1;
        let str = "";
        let warnsReason = "";
        if (reason === null) warnsReason = "None";
        if (reason != null) warnsReason = `\n${reason.map(x => `**${index++}.** ${x}`).join("\n")}`;
        if (warnsCount === null) str = "None";
        if (warnsCount != null) str = warnsCount;
        let embed = new Discord.MessageEmbed()
            .setDescription(`Warn check in [${message.guild.name}](https://id?=${message.guild.id})\n**Checking:** [${mentioned.tag}](https://id?=${mentioned.id})\n**By:** [${message.author.tag}](https://id?=${message.author.id})\n**Warns:** ${str}\n**Reasons:** ${warnsReason}`)
            .setColor("#6762A6");
        message.channel.send(embed);
    };
    if(args[1] === "-s") {
        let reason = db.get(`warns_reason_in_${message.guild.id}_for_${mentioned}`);
        let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
        let index = 1;
        let str = "";
        let warnsReason = "";
        if (warnsCount === 0) str = "None";
        if (warnsCount != 0) str = warnsCount;
        if (reason === null) warnsReason = "None";
        if (reason != null) warnsReason = `\n${reason.map(x => `**${index++}.** ${x}`).join("\n")}`;
        let embed = new Discord.MessageEmbed()
            .setDescription(`Warn check in [${message.guild.name}](https://id?=${message.guild.id})\n**Checking:** [${mentioned.tag}](https://id?=${mentioned.id}) \n**Warns:** ${str}\n**Reasons:** ${warnsReason}`)
            .setColor("#6762A6");
        message.author.send(embed);
        message.delete();
    };
};
module.exports.config = {
    name: "checkwarn",
    description: "Checks mentioned warns (provided with reasons, -s to send them in your DMs.)",
    usage: "checkwarn <mentioned> [-s]",
    accessableby: "Moderators",
    aliases: ["cw", "cwarn"],
    example: ["\ncheckwarn @Discord_Guy62", "\ncheckwarn @Discord_Guy62 -s"],
    input: "checkwarn @Discord_Guy62\n \n \n \n",
    output: "*Embed\nWarn check in x\nChecking: Discord_Guy62#6201\nBy: You#0423\n...",
    warning: "safe"
}