exports.run = async (client, message, args) => {
  const serverQueue = message.client.queue.get(message.guild.id);
  if (serverQueue && !serverQueue.playing) {
    serverQueue.playing = true;
    serverQueue.connection.dispatcher.resume();
    return message.channel.send("▶️ The song has been resumed!");
  }
  return message.channel.send("There is nothing playing.");
};
module.exports.config = {
  name: "resume",
  description: "Resumes the current paused song.",
  usage: "resume",
  accessableby: "Members",
  aliases: ["r", "re"],
  example: ["resume"],
  input: "resume\n \n \n \n",
  output: "▶️ The song has been resumed!\n \n \n \n",
  warning: "safe"
}