const Discord = require('discord.js');
const randomPuppy = require('random-puppy');

exports.run = async (client, message, args) => {
    const subReddits = ["meme", "me_irl", "dankmemes", "comedyheaven", "comedycemetary"]
    const random = subReddits[Math.floor(Math.random() * subReddits.length)];
    const img = await randomPuppy(random);
    const embed = new Discord.MessageEmbed()
    .setTitle(`Post from r/${random}`)
    .setImage(img)
    .setURL(`https://reddit.com/${random}`)
    .setColor(`RANDOM`)

    message.channel.send(embed)
}
module.exports.config = {
    name: "meme",
    description: "Gives a fetched meme from meme subreddits.",
    usage: "meme",
    example: "meme",
    accessableby: "Members",
    aliases: [],
    example: ["meme"],
    input: "meme\n \n \n \n",
    output: "*Embed\nPost from r/...\n.jpg image\n \n",
    warning: "If doesn't respond, execute command again."
}