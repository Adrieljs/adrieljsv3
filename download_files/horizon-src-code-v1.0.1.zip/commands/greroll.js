const ms = require('ms');

exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "Giveaways Manager")){
        return message.channel.send('You need \`ADMINISTRATOR\` permission or \`Giveaways Manager\` role');
    }

    // If no message ID or giveaway name is specified
    if(!args[0]){
        return message.channel.send('No valid message ID was provided. Example: \`741980723824689212\`');
    }

    // try to found the giveaway with prize then with ID
    let giveaway = 
    // Search with giveaway prize
    client.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
    // Search with giveaway ID
    client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

    // If no giveaway was found
    if(!giveaway){
        return message.channel.send('Unable to find a giveaway for `'+ args.join(' ') +'`.');
    }

    // Reroll the giveaway
    client.giveawaysManager.reroll(giveaway.messageID)
    .then(() => {
        // Success message
        message.channel.send('Giveaway has been rerolled!');
    })
    .catch((e) => {
        if(e.startsWith(`Giveaway with message ID \`${giveaway.messageID}\` hasn\'t ended!`)){
            message.channel.send('This giveaway hasn\'t ended!');
        } else {
            console.error(e);
            message.channel.send('An error occured whilst trying to execute this command and it has been logged.');
        }
    });

};
module.exports.config = {
    name: "greroll",
    description: "Rerolls a giveaway with provided Giveaway message ID.",
    usage: "greroll <Giveaway ID>",
    accessableby: "Admins",
    aliases: ["g-reroll", "gr"],
    example: ["greroll 747336462223147168"],
    input: "greroll 747336462223147168\n*THIS ID WON'T WORK!\n \n \n",
    output: "Giveaway has been rerolled!\n \n \n \n",
    warning: "Use this after a giveaway has ended."
}
