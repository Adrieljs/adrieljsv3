exports.run = async (client, message, args) => {
  let votes = message.client.votes.get(message.guild.id);
  const { channel } = message.member.voice;
  const saizu = message.member.voice.channel.members.size;
  const saiz2 = Math.ceil(saizu - 1);
  const actsiz = Math.ceil(saiz2 / 2);
  if (!channel)
    return message.channel.send(
      "Please connect to a voice channel."
    );
  const serverQueue = message.client.queue.get(message.guild.id);
  if (!serverQueue)
    return message.channel.send(
      "There is nothing playing."
    );
    if(!message.member.hasPermission('MANAGE_CHANNELS') && !message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "DJ")) {
      if(votes.voters.includes(message.author.id)) return message.channel.send(`📫 You have already voted! **(${votes.votes}/${actsiz})** votes!`); 
      votes.votes++
      votes.voters.push(message.author.id);
      message.channel.send(`📨 You have voted to skip! **(${votes.votes}/${actsiz})** votes!`);
      if(votes.votes >= actsiz) { serverQueue.connection.dispatcher.end()
      message.channel.send("⏭️ Skipped the song!");
      };
    } else {
  serverQueue.connection.dispatcher.end();
  return message.channel.send("⏭️ Skipped the song!");
  }
};
module.exports.config = {
  name: "skip",
  description: "Skips the current music.",
  usage: "skip",
  accessableby: "Members",
  aliases: ["s"],
  example: ["skip"],
  input: "skip\n \n \n \n",
  output: "📨 You have voted to skip! (x/x) votes!\n⏭️ Skipped the song!\n \n \n",
  warning: "safe"
}
