const ms = require('ms');
const config = require(`../config.json`)

exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "Giveaways Manager")){
        return message.channel.send('You need \`ADMINISTRATOR\` permission or \`Giveaways Manager\` role');
    }

    // Giveaway channel
    let giveawayChannel = message.mentions.channels.first();
    // If no channel is mentionned
    if(!giveawayChannel){
        return message.channel.send('No valid channel was provided. Example: \`#my-giveaways\`');
    }

    // Giveaway duration
    let giveawayDuration = args[1];
    // If the duration isn't valid
    if(!giveawayDuration || isNaN(ms(giveawayDuration))){
        return message.channel.send('No valid duration was provided. Example: \`10d\`');
    }

    // Number of winners
    let giveawayNumberWinners = args[2];
    // If the specified number of winners is not a number
    if(isNaN(giveawayNumberWinners) || (parseInt(giveawayNumberWinners) <= 0)){
        return message.channel.send('No valid winners count was provided. Example: \`5\` for 5 winners.');
    }

    // Giveaway prize
    let giveawayPrize = args.slice(3).join(' ');
    // If no prize is specified
    if(!giveawayPrize){
        return message.channel.send('No valid prize was provided. Example: \`My peepee and poopoo\`');
    }

    // Start the giveaway
    client.giveawaysManager.start(giveawayChannel, {
        // The giveaway duration
        time: ms(giveawayDuration),
        // The giveaway prize
        prize: giveawayPrize,
        // The giveaway winner count
        winnerCount: giveawayNumberWinners,
        hostedBy: config.hostedBy ? message.author : null,
        // Messages
        messages: {
            giveaway: "",
            giveawayEnded: "",
            timeRemaining: "Time remaining: **{duration}**!",
            inviteToParticipate: "React with 🎉 to participate!",
            winMessage: "Congratulations, {winners}! You won **{prize}**!",
            embedFooter: "Giveaway!",
            noWinner: "Giveaway has been cancelled, not enough participants entered.",
            hostedBy: "Hosted by: {user}",
            winners: "winner(s)",
            endedAt: "Ended at",
            units: {
                seconds: "seconds",
                minutes: "minutes",
                hours: "hours",
                days: "days",
                pluralS: false // Not needed, because units end with a S so it will automatically removed if the unit value is lower than 2
            }
        }
    });

};
module.exports.config = {
    name: "gstart",
    description: "",
    usage: "gstart <mentioned channel> <time> <winners> <prize>",
    accessableby: "Admins",
    aliases: ["g-start", "gs"],
    example: ["gstart #my-giveaways 2d 1 Cookies"],
    input: "gstart #my-giveaways 25m 10 Cookies\n \n \n \n",
    output: "Giveaway started in #my-giveaways!\n*Embed\ncookies\nReact with 🎉 to participate!\n...",
    warning: "Picks winners below winnercount if the winner goal is not reached."
}