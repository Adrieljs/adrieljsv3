exports.run = async (client, message, args) => {
    const channel = message.member.voice
    if (!channel) return message.channel.send("Please connect to a voice channel.");
    const serverQueue = message.client.queue.get(message.guild.id);
    if (!serverQueue) return message.channel.send("There is nothing playing.");

    serverQueue.loop = !serverQueue.loop

    return message.channel.send(`🔁 ${serverQueue.loop ? `**Enabled**` : `**Disabled**`} loop`);
}

module.exports.config = {
    name: "loop",
    description: "Loops the current song.",
    usage: "loop",
    accessableby: "Member",
    aliases: [],
    example: ["loop"],
    input: "loop\n \n \n \n",
    output: "Mines with spoilers\n \n \n \n",
    warning: "safe"
}