const translate = require('translate');
const config = require('../config.json');
exports.run = async (client, message, args) => {
    if (!args[0]) return message.channel.send("Hey! Provide a valid language!");
    if (!args[1]) return message.channel.send("Hey! Provide a text to be translated to.");
    if (args[1]) {
        try {
    translate.engine = "google";
    translate.key = config["api-translate"];
    let tr = await translate(args.slice(1).join(" "), args[0]);
    message.channel.send(tr);
        } catch (e) {
            message.channel.send(`There was an error!`)
        };
    };
}
module.exports.config = {
    name: "translate",
    description: "Translates from english to provided language",
    usage: "translate",
    accessableby: "Members",
    aliases: ["t"],
    example: ["translate es hello world!"],
    input: "translate es hello world!\n \n \n \n",
    output: "¡hola mundo!\n \n \n \n",
    warning: "safe"
  }