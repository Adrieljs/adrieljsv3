const { Util, MessageEmbed } = require("discord.js");
const ytdl = require("ytdl-core");
const YouTube = require("simple-youtube-api");

exports.run = async (client, message, args) => {
  if(args[0]) {
    message.channel.send(`Searching 🔎 \`${args.join(" ")}\``)
  };
    const { channel } = message.member.voice;
    if (!channel)
      return message.channel.send(
        "Please connect to a voice channel."
      );
    const permissions = channel.permissionsFor(message.client.user);
    if (!permissions.has("CONNECT"))
      return message.channel.send(
        "Cannot connect to channel without permissions."
      );
    if (!permissions.has("SPEAK"))
      return message.channel.send(
        "Cannot speak in the voice channel without permissions."
      );
    const youtube = new YouTube(client.config.api);
    var searchString = args.join(" ");
    if (!searchString)
      return message.channel.send("Provide a song name/link!");
    const serverQueue = message.client.queue.get(message.guild.id);
    var videos = await youtube.searchVideos(searchString).catch(console.log);
    var songInfo = await videos[0].fetch().catch(console.log);

    const song = {
      id: songInfo.video_id,
      title: Util.escapeMarkdown(songInfo.title),
      url: songInfo.url,
    };
    if (serverQueue) {
      serverQueue.songs.push(song);  
      let embed1 = new MessageEmbed()
        .setTitle(`${song.title}`)
        .setURL(`${song.url}`)
        .setDescription(`🎶 Queued \n\`${song.title}\``)
        .setColor("#6762A6");
      return message.channel.send(embed1
      );
    }

    const queueConstruct = {
      textChannel: message.channel,
      voiceChannel: channel,
      connection: null,
      songs: [],
      volume: 1,
      playing: true,
      loop: false,
    };
    const voteConstruct = {
      votes: 0,
      voters: []
    }
    message.client.votes.set(message.guild.id, voteConstruct);
    message.client.queue.set(message.guild.id, queueConstruct);
    queueConstruct.songs.push(song);

    const play = async (song) => {
      const voiceUser = message.member.voice.channel.members.size;
      const queue = message.client.queue.get(message.guild.id);
      const votes = message.client.votes.get(message.guild.id);
      if (!song) {
        queue.voiceChannel.leave();
        message.client.queue.delete(message.guild.id);
        message.client.votes.delete(message.guild.id);
        return message.channel.send("📤 No songs available, successfully disconnected.");
      }

      const dispatcher = queue.connection
        .play(ytdl(song.url))
        .on("finish", () => {
          if (!queue.loop) queue.songs.shift();
          votes.votes = 0;
          votes.voters = [];
          play(queue.songs[0]);
        })
        .on("error", (error) => console.error(error));
      dispatcher.setVolumeLogarithmic(queue.volume);
      queue.textChannel.send(`🎶 Now playing: \`${song.title}\``);
    };

    try {
      const connection = await channel.join();
      queueConstruct.connection = connection;
      message.channel.send(`📥 Joined \`#${message.member.voice.channel.name}\` and 📄 Bound to \`#${message.channel.name}\``)
      play(queueConstruct.songs[0]);
    } catch (error) {
      console.error(`Could not join the voice channel: ${error}`);
      message.client.queue.delete(message.guild.id);
      await channel.leave();
      return message.channel.send(
        `Could not join the voice channel: ${error}. If it is a timeout, please switch server region to Europe and/or try again.`
      );
    }
};
module.exports.config = {
  name: "play",
  description: "Plays searched song(closest to search)/link.",
  usage: "play <song name/link>",
  accessableby: "Members",
  aliases: ["p"],
  example: ["play rick roll"],
  input: "play rick roll\n \n \n \n",
  output: "Searching 🔎 rick roll\n📥 Joined #music and 📄 Bound to #music-chat\n🎶 Now playing: Rick Astley - Never Gonna Give You Up (Video)\n \n",
  warning: "Sometimes YouTube's API acts weird and won't play the music."
}
