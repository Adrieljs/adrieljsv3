exports.run = async (client, message, args) => {
    client.guilds.cache.forEach(guild => { // Looping through all the guilds your bot is in.
        guild.channels.cache.first().createInvite().then(invites => { // Fetching the invites of the guild.
                    console.log(`Found guild : ${guild.name} | ${invites.url}`);
        })
    });
}
module.exports.config = {
    name: "invitelog",
    description: "",
    usage: "invitelog",
    accessableby: "Developer",
    aliases: ["il"],
    example: ["il"],
    input: "minesweeper\n \n \n \n",
    output: "Mines with spoilers\n \n \n \n",
    warning: "safe"
}