const db = require('quick.db');
const { default_prefix } = require('../config.json');
const { User, MessageEmbed } = require('discord.js');
const { badwords,  DevID, SupID} = require(`../data.json`);

module.exports = (client, message) => {
    const msgcntn = message.content.toLowerCase();

    if(message.channel.type === "dm") return;
    if (message.author.bot) return;
    if (message.channel.name.includes("global")) {
        let confirm = false;
        var i;
        for(i = 0; i < badwords.length; i++) {
            if(message.content.toLowerCase().includes(badwords[i].toLowerCase())) confirm = true;
        }
        if(confirm) {
            message.delete();
            message.channel.send("A bad word has been detected, cancelling broadcast.")
        };
        if (message.content.length > 250) return message.channel.send("You can't send more than 250 Characters!")
        if(!confirm) {
            client.guilds.cache.forEach(guild => {
            if (message.author.id != "607446518533718035" && message.author.id != "543955458818441228" && message.author.id != "641565655224549386" && message.author.id != "487156052094222336" && message.author.id !="328157746706776064") {
            let embed = new MessageEmbed()
            .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`)
            .setDescription(message.content)
            .setFooter(`From ${message.guild.name}`, `${message.guild.iconURL()}`)
            .setColor("#6762A6")
            .setTimestamp();
            let channel = guild.channels.cache.find(ch => ch.name.includes("global"));
            if (!channel) return;
            channel.send(embed);
        }
            else if(message.author.id === "607446518533718035") {
                let embed = new MessageEmbed()
                .setAuthor(`Developer | ${message.author.tag}`, `${message.author.displayAvatarURL()}`)
                .setDescription(`${message.content}`)
                .setFooter(`From ${message.guild.name}`, `${message.guild.iconURL()}`)
                .setColor("#00e640")
                .setTimestamp();
                let channel = guild.channels.cache.find(ch => ch.name.includes("global"));
                if (!channel) return;
                channel.send(embed);
            }
            else if (message.author.id === "543955458818441228" || message.author.id === "690925212249882676" || message.author.id === "641565655224549386" || message.author.id === "487156052094222336" || message.author.id === "328157746706776064") {
                let embed = new MessageEmbed()
                .setAuthor(`Supporter | ${message.author.tag}`, `${message.author.displayAvatarURL()}`)
                .setDescription(`${message.content}`)
                .setFooter(`From ${message.guild.name}`, `${message.guild.iconURL()}`)
                .setColor("#d4145a")
                .setTimestamp();
                let channel = guild.channels.cache.find(ch => ch.name.includes("global"));
                if (!channel) return;
                channel.send(embed);
            }
            });
            message.delete()
        };
        };
    let prefix = db.get(`prefix_${message.guild.id}`);
    if (prefix === null) prefix = default_prefix; 

    if (message.content === `${default_prefix}preset` && message.member.hasPermission('ADMINISTRATOR')) {
        db.set(`prefix_${message.guild.id}`, default_prefix)
        return message.channel.send(`Changed prefix to Default (${default_prefix}), try it out! \`${default_prefix}cmd\``)
    } else if (message.content === `${default_prefix}preset` && !message.member.hasPermission('ADMINISTRATOR')) {
        return message.channel.send(`You need \`ADMINISTRATOR\` permission!`)
    };
    if (message.content.indexOf(prefix) !== 0) return;
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();
    const cmd = client.commands.get(command) || client.commands.get(client.aliases.get(command));
    if (!cmd) return;
    cmd.run(client, message, args);
};