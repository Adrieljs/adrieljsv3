const fs = require('fs');

const Discord = require('discord.js');
const client = new Discord.Client();
const Enmap = require('enmap');
const config = require('./config.json');;
client.config = config;
client.config = {
    api: config["api-youtube"]
  };
client.votes = new Map();
client.commands = new Enmap();
client.aliases = new Enmap();
client.queue = new Map();
client.snipes = new Map();
const { GiveawaysManager } = require("discord-giveaways");
const db = require("quick.db");
if(!db.get("giveaways")) db.set("giveaways", []);

const GiveawayManagerWithOwnDatabase = class extends GiveawaysManager {
    async getAllGiveaways(){
        return db.get("giveaways");
    }
    async saveGiveaway(messageID, giveawayData){
        db.push("giveaways", giveawayData);
        return true;
    }
    async editGiveaway(messageID, giveawayData){
        const giveaways = db.get("giveaways");
        const newGiveawaysArray = giveaways.filter((giveaway) => giveaway.messageID !== messageID);
        newGiveawaysArray.push(giveawayData);
        db.set("giveaways", newGiveawaysArray);
        return true;
    }
    async deleteGiveaway(messageID){
        const newGiveawaysArray = db.get("giveaways").filter((giveaway) => giveaway.messageID !== messageID);
        db.set("giveaways", newGiveawaysArray);
        return true;
    }

};

client.on("channelCreate", async (channel) => {
    if (channel.name.includes("global")) {
    let embed = new Discord.MessageEmbed()
        .setTitle(`A global chat channel has been detected.`)
        .setDescription(` __#${channel.name}__\n=> All things that happened in this chat is NOT my responsibility, by creating this channel, you accept and understand the risks and consequenses, and only words that are considered to be bad will be censored from global chat. Check \`(prefix)global\` for more information.`)
        .setColor("#6762A6");
    channel.send(embed);
    };
});
let y = process.openStdin();
y.addListener("data", res => {
    let x = res.toString().trim().split(/ +/g)
    client.guilds.cache.forEach(guild => {
        let embed = new Discord.MessageEmbed()
        .setAuthor(`Console`, `https://cdn.discordapp.com/attachments/731392963669655633/749617052062449664/2020-08-30.png`)
        .setDescription(x.join(" "))
        .setFooter(`From console`, `https://cdn2.iconfinder.com/data/icons/nodejs-1/512/nodejs-512.png`)
        .setColor("#57de72")
        .setTimestamp();
        let channel = guild.channels.cache.find(ch => ch.name.includes("global"));
        if (!channel) return;
        channel.send(embed);
});
});
const manager = new GiveawayManagerWithOwnDatabase(client, {
    storage: false,
    updateCountdownEvery: 10000,
    default: {
        botsCanWin: false,
        exemptPermissions: [ "MANAGE_MESSAGES", "ADMINISTRATOR" ],
        embedColor: "#6762A6",
        reaction: "🎉"
    }
});
client.giveawaysManager = manager;
client.giveawaysManager.on("giveawayReactionAdded", (giveaway, member, reaction) => {
    console.log(`${member.user.tag} entered giveaway #${giveaway.messageID} (${reaction.emoji.name})`);
});

client.giveawaysManager.on("giveawayReactionRemoved", (giveaway, member, reaction) => {
    console.log(`${member.user.tag} unreact to giveaway #${giveaway.messageID} (${reaction.emoji.name})`);
});

/* Load all events */
fs.readdir("./events/", (_err, files) => {
    files.forEach((file) => {
        if (!file.endsWith(".js")) return;
        const event = require(`./events/${file}`);
        let eventName = file.split(".")[0];
        console.log(`| Event loaded: ${eventName}`);
        client.on(eventName, event.bind(null, client));
        client.on("guildCreate", guild => {
            console.log(`New guild joined: ${guild.name} (id: ${guild.id}). This guild has ${guild.memberCount} members!`);
            client.user.setActivity(`${client.guilds.cache.size} servers! | h!help`, { type: 'WATCHING' })
          });          
        client.on("guildDelete", guild => {
            // this event triggers when the bot is removed from a guild.
            console.log(`I have been removed from: ${guild.name} (id: ${guild.id})`);
            client.user.setActivity(`${client.guilds.cache.size} servers! | h!help`, { type: 'WATCHING' })
          });
        delete require.cache[require.resolve(`./events/${file}`)];
    });
});
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
fs.readdir("./commands/", (_err, files) => {
    files.forEach((file) => {
        if (!file.endsWith(".js")) return;
        let props = require(`./commands/${file}`);
        let commandName = file.split(".")[0];
        client.commands.set(commandName, props);
        props.config.aliases.forEach(alias => {
            client.aliases.set(alias, props.config.name)
        });
        console.log(`| Command loaded: ${commandName}`);
    });
});

client.login(config.token);