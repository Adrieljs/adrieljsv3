const Minesweeper = require('discord.js-minesweeper');
exports.run = async (client, message, args) => {
    const minesweeper = new Minesweeper({
        revealFirstCell: true,
        zeroFirstCell: true,
        returnType: 'emoji'
    })
    const mine = minesweeper.start();
    message.channel.send(mine)
}
module.exports.config = {
    name: "minesweeper",
    description: "Generates a minesweeper game.",
    usage: "minesweeper",
    accessableby: "Members",
    aliases: ["ms"],
    example: ["minesweeper"],
    input: "minesweeper\n \n \n \n",
    output: "Mines with spoilers\n \n \n \n",
    warning: "safe"
}