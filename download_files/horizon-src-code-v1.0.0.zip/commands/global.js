const { MessageEmbed } = require("discord.js")

exports.run = async (client, message, args) => {
    let embed = new MessageEmbed()
        .setTitle("About global-chat")
        .setDescription("So you're interested in global chat huh? Well, this is the guide and a bit information about it.\n\n**So what is global chat?**\nIt is a cross-server channel text, basically you reveive another message from another server, and then the message will appear in the global chat channel in your server.\n\n**How do i set up global chat?**\nWell, it is easy! just make a channel name that includes the name \"global\" and yes! everything works even \`#asdfg-globalwg-fd😄\` as long as it includes the word \"global\" in it. If it is successfull, it will send an embed containing a message on accepting the things below.\n\n**By creating the channel, you accept that:**\n- You continue at your own consequenses.\n-Everything that happens in the chat is not my responsibility\n- I can not control the chat, i can only add swear filters.\n- Even if something bad happens in the chat, i could not stop it. Except making the bot force leave from the sender server.\n- Don't worry about pings, embeds doesn't ping.")
        .setColor("#6762A6");
message.channel.send(embed);
};
module.exports.config = {
    name: "global",
    description: "",
    usage: "global",
    accessableby: "",
    aliases: [],
    example: [],
    input: "",
    output: "",
    warning: ""
}