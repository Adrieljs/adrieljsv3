exports.run = async (client, message, args) => {
  const { channel } = message.member.voice;
  if (!channel)
    return message.channel.send(
      "Please connect to a voice channel."
    );
  const serverQueue = message.client.queue.get(message.guild.id);
  if (!serverQueue) return message.channel.send("There is nothing playing.");
  if (!args[0])
    return message.channel.send(
      `🔊 Current volume is **${serverQueue.volume}**`
    );
    if(args[0] === "-bypass") {
      if (isNaN(args[1])) return message.channel.send("Cannot turn the volume up/down. Provide a valid value!");
      serverQueue.volume = args[1]; 
      serverQueue.connection.dispatcher.setVolumeLogarithmic(args[1]);
      return message.channel.send(`🔊 Volume has been set to **${args[1]}** with a global bypass.`);
    }
    if(args[0] != "-bypass") {
      if (isNaN(args[0])) return message.channel.send("Cannot turn the volume up/down. Provide a valid value!");
      if(args[0] < 1) return message.channel.send("Can't set a volume below 1!")
      if (args[0] > 10) return message.channel.send("Volume is limited to 10 to prevent ear damage. Bypass this by using \`(prefix)volume -bypass <value>\` Continue at your own risk.")
      serverQueue.volume = args[0]; 
      serverQueue.connection.dispatcher.setVolumeLogarithmic(args[0]);
      return message.channel.send(`🔊 Volume has been set to **${args[0]}**`);
  };
}

exports.config = {
  name: "volume",
  description: "Sets music volume output to provided number (1-10)",
  usage: "volume <number>",
  accessableby: "Members",
  aliases: ["v", "vol"],
  example: ["volume 2"],
  input: "volume 2\n \n \n \n",
  output: "🔊 Volume has been set to 2\n \n \n \n",
  warning: "Volume limited/maxed at 10 to prevent ear damage."
}