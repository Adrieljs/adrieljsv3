const figlet = require('figlet');
const db = require('quick.db');
const { default_prefix } = require('../config.json');

exports.run = async (client, message, args) => { 
    let prefix = db.get(`prefix_${message.guild.id}`);
    if (prefix === null) prefix = default_prefix; 
    if(!args[0]) return message.channel.send('Provide a valid text! Example: \`Hello World!\`');
    msg = args.join(" ");
    if (args[0] != "help") {
    figlet.text(msg, function (err, data) {
        if(data.length > 2000) return message.channel.send("Provide a text shorter than 2000 chars.");
        message.channel.send('```' + data + '```');
    })
    }
}
module.exports.config = {
    name: "ascii",
    description: "Turns provided text into an ascii text.",
    usage: "ascii <text>",
    accessableby: "Members",
    aliases: [],
    example: ["ascii hi"],
    input: "ascii hi\n \n \n \n",
    output: "\n   _     _ \n    | |__ (_)\n    | '_ \| |\n    | | | | |\n    |_| |_|_|",
    warning: "Keep output characters under 2000, recommended character input is 9 for mobile users and 15 for pc users."
}