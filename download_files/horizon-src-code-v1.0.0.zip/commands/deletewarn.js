const db = require('quick.db');
const Discord = require('discord.js');
exports.run = async (client, message, args) => {
    if(!message.member.hasPermission('MANAGE_MESSAGES') || !message.member.hasPermission('ADMINISTRATOR') && !message.member.roles.cache.some((r) => r.name === "Moderator")) {
    return message.channel.send("You need \`MANAGE_MESSAGES\` permission or \`Moderator\` role!");
};
    let mentioned = message.mentions.users.first();
    if(args[0] === !mentioned) return message.channel.send(
        "Provide a valid mentioned user to delete their warns!"
        );
    if(mentioned === undefined) return message.channel.send(
    "Provide a valid mentioned user to delete their warns!"
    );
    if(mentioned === message.author) return message.channel.send(
        "You can't delete your own warns!"
        );
    if(mentioned.bot) return message.channel.send(
        "You can't warn bots, therefore bots warns are **0** and cannot be deleted."
    );
    let warnsCount = db.get(`warns_in_${message.guild.id}_for_${mentioned}`);
    if (warnsCount === null) return message.channel.send(
        "Mentioned user has no warns!"
    );
    db.delete(`warns_reason_in_${message.guild.id}_for_${mentioned}`);
    db.delete(`warns_in_${message.guild.id}_for_${mentioned}`);
    message.channel.send(`Successfully deleted **${warnsCount}** warns for **${mentioned.tag}**!`);
};
module.exports.config = {
    name: "deletewarn",
    description: "Deletes mentioned warns, including the reasons.",
    usage: "deletewarn <mentioned>",
    accessableby: "Moderators",
    aliases: ["dw", "dwarn"],
    example: ["dwarn @Discord_Guy62"],
    input: "deletewarn @Discord_Guy62\n \n \n \n",
    output: "Successfully deleted 2 warns from Discord_Guy62#6201!\n \n \n \n ",
    warning: "safe"
}