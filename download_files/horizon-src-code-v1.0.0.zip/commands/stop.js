exports.run = async (client, message, args) => {
  const serverQueue = message.client.queue.get(message.guild.id);
  if (serverQueue && serverQueue.playing) {
    serverQueue.playing = false;
    serverQueue.connection.dispatcher.pause();
    return message.channel.send("⏸ The song has been paused.");
  }
  return message.channel.send("There is nothing playing.");
};
module.exports.config = {
  name: "stop",
  description: "Stops/pause current music.",
  usage: "stop",
  accessableby: "Members",
  aliases: ["pause"],
  example: ["stop"],
  input: "stop\n \n \n \n",
  output: "⏸ The song has been paused.\n \n \n \n",
  warning: "safe"
}