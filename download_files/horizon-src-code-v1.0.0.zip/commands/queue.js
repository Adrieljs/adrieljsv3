const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  const serverQueue = message.client.queue.get(message.guild.id);
  let index = 1;
  let string = "";
    if (serverQueue.songs[0]) string += `__Now Playing__\n[${serverQueue.songs[0].title}](${serverQueue.songs[0].url})\n\n`;
    if (serverQueue.songs[1]) string += `__Next Up__\n${serverQueue.songs.slice(1, 10).map(x => `**${index++}.** [${x.title}](${x.url})`).join("\n\n")}`;
  const embed = new Discord.MessageEmbed()
    .setTitle(`Queue for ${message.guild.name}`)
    .setDescription(string)
    .setColor("#6762A6");
  if (!serverQueue) return message.channel.send("There is nothing playing.");
  return message.channel.send(embed);
};
module.exports.config = {
  name: "queue",
  description: "Gets music queue from the server.",
  usage: "queue",
  accessableby: "Members",
  aliases: ["q"],
  example: ["queue"],
  input: "queue\n \n \n \n",
  output: "*Embed\nQueue for x\n__Now Playing__\n1. x\n...",
  warning: "safe"
}
