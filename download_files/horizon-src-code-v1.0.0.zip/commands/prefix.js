const db = require('quick.db');
const { Channel } = require('discord.js');

exports.run = async (client, message, args) => {
    if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('You need \`ADMINISTRATOR\` permission!');

    if (!args[0]) return message.channel.send('Provide a valid prefix!');

    if (args[1]) return message.channel.send('Provide a prefix without double arguments!');

    if (args[0].length > 4) return message.channel.send('Prefix cannot be more than 4 characters!')

    if (args[0] === 'def') {
        db.set(`prefix_${message.guild.id}`, 'h!')
        return message.channel.send(`Changed prefix to Default (pp!), try it out! \`pp!cmd\``)
    } else {
        db.set(`prefix_${message.guild.id}`, args[0])
        return message.channel.send(`Changed prefix to \`${args[0]}\` , try it out! \`${args[0]}cmd\``)
    }
}
module.exports.config = {
    name: "prefix",
    description: "Changes prefix for this server.",
    usage: "prefix <prefix>",
    accessableby: "Admins",
    aliases: ["pre", "pr"],
    example: ["prefix hor!"],
    input: "prefix h?\n \n \n \n",
    output: "Changed prefix to h? , try it out! h?cmd\n \n \n \n",
    warning: "safe"
}